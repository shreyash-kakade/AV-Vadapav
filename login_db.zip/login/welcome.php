<?php
  session_start();  // First start the session
  if(!isset($_SESSION['loggedIn']) || $_SESSION['loggedIn'] != true)
  {
    header('Location:./login.php');  // redirect to login.php
    session_unset();  // Will free all variables set in this session
    session_destroy();  // will destroy this session
    exit(); // It will terminate this php file
  }
?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Welcome</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  </head>
  <body>
    <?php
        require("./partials/_nav.php");
    ?>
    <h1>Hello - <?php echo $_SESSION['username'];?></h1>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
  </body>
</html>